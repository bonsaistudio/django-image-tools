from distutils.core import setup

setup(name='django-image-tools',
      version='1.0',
      description='Image tools for Django',
      author='Bonsai Studio',
      author_email='info@bonsai-studio.net',
      url='http://github.com/xelhark/django-image-tools',
      packages=['django_image_tools', ],
     )